import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from 'react-native';

export default function App() {
  return (
    <View style={styles.container}>
      <Text>Welcome to the Incredible To Do List App!</Text>
      <StatusBar style="auto" />
      <Text>Today's To Do List:
      </Text><Text>1. Go To Gym</Text>
      <Text>2. Get Groceries</Text>
      <Text>3. Wash Car</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'red',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
